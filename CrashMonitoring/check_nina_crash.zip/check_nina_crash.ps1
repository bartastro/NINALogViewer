# --- CONFIGURATIE ---
$DiscordWebhookURL = "Rc9hjaIzP50moJaBb2beqTYCdbmlurhh9KN1nYv9b2bukAgzxBTCU7c2JXTglPYdTFmS"

# Zoek de meest recente crash (Event ID 1000) in de Application logs
$CrashEvent = Get-WinEvent -LogName Application -FilterHashtable @{ID=1000; Level=2} -MaxEvents 1 -ErrorAction SilentlyContinue

if ($CrashEvent) {
    $EventMessage = $CrashEvent.Message
   
    # Controleer of NINA de dader was
    if ($EventMessage -like "*NINA.exe*" -or $EventMessage -like "*werfault.exe" -or $EventMessage -like "*crash.exe") {
       
        # Tijdstip mooi formatteren
        $Tijdstip = $CrashEvent.TimeCreated.ToString("dd-MM-yyyy HH:mm:ss")
		
		$Titel = "!! NINA crash gedetecteerd !!"

		if ($EventMessage -like "*werfault.exe") { $Titel = "NINA detector -- Test OK"}
		
        # Discord Embed JSON structuur opbouwen
        $Body = @{
            embeds = @(
                @{
                    title       = $Titel
                    description = "NINA is zojuist onverwacht gecrasht op de remote setup."
					# Dit is een rode kleur of een groene (Hex #E74C3C omgezet naar Decimaal)
                    color       = if ($Titel -like "*Test*") { 3066993 } else { 15158332 }
                    fields      = @(
                        @{
                            name  = "Tijdstip"
                            value = $Tijdstip
                            inline = $true
                        },
                        @{
                            name  = "Systeem"
                            value = $env:COMPUTERNAME
                            inline = $true
                        }
                    )
                    footer      = @{
                        text = "Windows Event Viewer - ID 1000"
                    }
                }
            )
        } | ConvertTo-Json -Depth 4

        # Bericht naar Discord schieten
        Invoke-RestMethod -Uri $DiscordWebhookURL -Method Post -Body $Body -ContentType "application/json"
    }
} else {
	Exit
}
